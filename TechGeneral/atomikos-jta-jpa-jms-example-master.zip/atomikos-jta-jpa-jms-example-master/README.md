# atomikos-jta-jpa-jms-example
An Atomikos JTA example with Spring, JPA and JMS

